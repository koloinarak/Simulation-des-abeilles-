//Nous faisons les import nécessaire pour utiliser les différentes structures de java
import java.awt.*;

class Abeille { //classe abeille
    //Création de variables
    int x, y , radius = 6; 
    Color c;

    Abeille(int x, int y, Color c) { //constructeur de abeille qui nous permet d'initialiser nos variables
        this.x = x;
        this.y = y;
        this.c = c;
    }

    int getX () {//nous permet de recuperer la valeur x de l'abeille (abscisse)
        return this.x;
    }

    int getY () {//nous permet de recuperer la valeur de y de l'abeille (ordonnée)
        return this.y;
    }

    void paint(Graphics g){ //nous permet d'afficher notre abeille
		g.setColor(this.c); //avec sa couleur respective
        g.fillOval(this.x-this.radius,this.y-this.radius,2*this.radius,2*this.radius); //et une forme ronde
	}

}