//Nous faisons les import nécessaire pour utiliser les différentes structures de java 
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Colonie { //Classe Colonie qui va nous permettre de lancer et de faire la simulation de la colonie d'abeille
    //Création de variables
    private ColoniePanel coloniePanel; //nous créons une variable de type ColoniePanel
    private ColonieFrame colonieFrame; //nous créons une variable de type ColonieFrame

    int valeur, nbAbeille, q, abeille; //nous créons des variables entiers
    int nb, nbSourceMax, nbObservatrices, nbEclaireuses, numeroN;
    int tailleCase, width, height, x, y;
    int sourceMAX, max ;
    Abeille[] ab; //Nous créons un tableau ab qui pourra contenir des données de type abeille
    SC[] sc; //Nous créons un tableau sc qui pourra contenir des données de type SC (Source de Nourriture)
    List<Integer> sourceExplore; //Nous créons une liste d'entier sourceExplore
    List<Integer> sourceSupprime; //Nous créons une liste d'entier sourceSupprime
    List<Integer> indiceSourceObservatrices; //Nous créons une liste d'entier indiceSourceObservatrices

    public Colonie(int width, int height, int taillecases, int nbsc) { //Constructeur de notre classe Colonie avec ses paramètres 
        this.valeur = (int) (Math.random() * nbsc) + 1; //Nous calculons aléatoirement le nombre de sources que nous allons avoir, minimum une source
        if(((width/taillecases) *(height/taillecases) - (width + height - 1) ) == valeur){ //Si le nombre de source trouvé remplirai le tableau entier en comptant la ruche et la ligne verticale et horizontale où se trouve la ruche, on va devoir changer le nombre de sources possibles 
            this.valeur = (width/taillecases) *(height/taillecases) - (width + height - 1); //Ainsi le nombre de cases possibles correspondra a tout le plateau sans compter la ruche et la ligne verticale et horizontale où se trouve la ruche, soit quand y = 0 ou quand x = 0
            System.out.println("La colonie ne peux pas contenir autant de sources. Il est donc limité à : " + valeur); //Nous signalons cette information à l'utilisateur
            //C'est un choix que nous avons fait, pour avoir quelque chose de plus propre, de laisser la premiere ligne horizontale et verticale vide, avec uniquement la source
        }
        else { //Si le nombre de source est inférieur
            System.out.println("Voici le nombre de sources : " + valeur); //Nous affichons le nombre de source pour le signaler à l'utilisateur
        }
        //Nous savons que nous aurons autant d'employées que de sources, donc la variable valeur compte pour les deux informations
        this.nbObservatrices = valeur + 20; //Le nombre d'observatrices va correspondre au nombre d'employée + 20
        this.nbEclaireuses = 20; //Le nombre d'éclaireuses est fixé à 20
        this.nbAbeille = this.valeur + this.nbObservatrices + this.nbEclaireuses; //Le nombre d'abeille, correspond donc à la somme de tous les types d'abeilles 
        this.indiceSourceObservatrices = new ArrayList<>(); //Nous initialisons les listes
        this.sourceExplore = new ArrayList<>();
        this.sourceSupprime = new ArrayList<>();
		this.ab = new Abeille[nbAbeille]; //Nous initialisons le tableau ab avec comme taille le nombre d'abeilles présentes lors de la simulation
        this.sc = new SC[valeur]; //Nous initialisons le tableau sc avec comme taille le nombre de sources de nourritures présentes lors de la simulation
        this.tailleCase = taillecases; //La taille des cases étant choisie par l'utilisateur, nous la stockons dans cette variable
        this.width = width; //La taille horizontale étant choisie par l'utilisateur, nous la stockons dans cette variable
        this.height = height; //La taille verticale étant choisie par l'utilisateur, nous la stockons dans cette variable
        this.sourceMAX = 0; //Nous initialisons sourceMAX à 0, plus petite valeur possible, puisque nous n'allons jamais avoir de source avec 0 comme qualité
        //Afin de différencier les abeilles, nous avons choisi de leur attribuer des couleurs différentes par type d'abeille
		for (int i = 0; i < this.valeur; i++){ //Nous allons commencer par créer les abeilles employées
			ab[i] = new Employees(this.tailleCase/2 , this.tailleCase/2 , Color.BLUE ); //Nous mettons dans le tableau ces abeilles avec leurs paramètre : leur position (x,y) et leur couleur bleu
		}
		for (int i = this.valeur ; i < this.valeur + this.nbEclaireuses; i++){ //Nous allons ensuite créer les abeilles éclaireuses, que l'on mettra dans le tableau à la suite des employée, il nous faut donc prendre le nombre d'employées et partir de là
			ab[i] = new Eclaireuses(this.tailleCase/2 , this.tailleCase/2 , Color.GREEN ); //Nous mettons dans le tableau ces abeilles avec leurs paramètre : leur position (x,y) et leur couleur verte
		}
		for (int i = this.valeur + this.nbEclaireuses; i < this.nbAbeille; i++){ //Nous allons ensuite créer les abeilles observatrices, que l'on mettra dans le tableau à la suite des éclaireuses, il nous faut donc prendre le dernier indice des éclaireuses et partir de là
			ab[i] = new Observatrices(this.tailleCase/2 , this.tailleCase/2 , Color.MAGENTA ); //Nous mettons dans le tableau ces abeilles avec leurs paramètre : leur position (x,y) et leur couleur magenta
		}
    	for (int i = 0; i < this.valeur; i++){ //Nous allons maintenant créer les sources de nourriture
            //Nous allons générer aléatoirement leur position
            this.x =  (int)(Math.random() * (this.width - this.tailleCase)) + this.tailleCase ; //Nous générons aléatoirement leur x en mettant comme taille minimale la taille d'une case
            this.y =  (int)(Math.random() * (this.height - this.tailleCase )) + this.tailleCase; //Nous générons aléatoirement leur y en mettant comme taille minimale la taille d'une case
            //En mettant comme minimum la taille d'une case, nous ne serons pas embêtés par la place de la ruche, ça permet également un affichage meilleur et de laisser la premiere ligne horizontale et verticale
            this.q =  (int)(Math.random() * (951)) + 50; //Nous générons aléatoirement des valeurs allant de 0 à 950 qui correspondent à la qualité des sources, avec comme minimum 50, puisque nous l'ajoutons par la suite
            while (!positionSource(x, y, q)){ //Nous allons regarder si nos valeurs respectent les conditions que nous voulons
                //Si ce n'est pas le cas nous rentrons dans la boucle et regénérons les valeurs
                this.x =  (int)(Math.random() * (this.width - this.tailleCase )) + this.tailleCase ; //Nous générons aléatoirement leur x en mettant comme taille minimale la taille d'une case
                this.y =  (int)(Math.random() * (this.height - this.tailleCase )) + this.tailleCase ;  //Nous générons aléatoirement leur y en mettant comme taille minimale la taille d'une case
                this.q =  (int)(Math.random() * (951)) + 50; //Nous générons aléatoirement des valeurs allant de 0 à 950 qui correspondent à la qualité des sources, avec comme minimum 50, puisque nous l'ajoutons par la suite
            }
			sc[i] = new SC(this.x , this.y, this.q, this.q/10 ); //Nous rajoutonss donc cette nouvelle source au tableau de sources, avec sa position, sa qualité, et son nombre de visite avant qu'elle soit détruite
            //Le nombre de visite dépend donc de la qualité, puisque nous faisons la qualité divisée par 10 pour obtenir le nombre de visite
            //Ce choix nous semble appropriée, puisque si la source à une qualitée élevée, il faudra plus de visite avant qu'elle ne soit détruite
            if (this.sourceMAX < this.q){ //Nous comparons la valeur de notre sourceMAX (qui vaut au début 0), avec la valeur de la qualité que nous venons de donner à la source
                this.sourceMAX = this.q ; //Si la qualité est plus importante on remplace la valeur de sourceMAX, par celle de la qualité. Ainsi dans sourceMAX nous aurons la qualité maximale qui est présente sur la fenêtre (puisque nous avons comparé avec toutes les sources crées)
            }
		}

        coloniePanel = new ColoniePanel(ab, sc, tailleCase); //Nous créons notre ColoniePanel qui permet l'affichage de tous les composants, en lui mettant certaines données en paramètre
        coloniePanel.setPreferredSize(new Dimension(width, height)); //Nous lui donnons une taille, celle choisie par l'utilisateur

        colonieFrame = new ColonieFrame(coloniePanel); //Nous créons notre ColonieFrame, qui permet l'affichage de quelques valeurs supplémentaires ainsi que de l'ensemble des Pannel dans notre fenêtre
    }

	public void run(){ //Nous avons ici notre méthode run, c'est celle ci qui va nous permettre tous les mouvements de la simulation
        colonieFrame.updateSourceMaxCount(sourceMAX); //Nous mettons à jour le JLabel avec la valeur de la meilleure qualité que nous avons stocké
        colonieFrame.updateNourriture(nbAbeille * 150); //Nous mettons à jour le JLabel avec la valeur de nourriture qu'il faut pour toutes nos abeilles
        System.out.println("Les éclaireuses interviennent"); //Nous informons l'utilisateur des abeilles qui vont intervenir

        for (int z = valeur ; z < valeur + nbEclaireuses; z ++ ){ //Nous créons une boucle pour faire faire certaines actions à toutes les éclaireuses
		    roleEclaireuses(z); //Nous appelons la méthode roleEclaireuses avec en paramètre le numéro de l'abeille
            colonieFrame.updateEclaireusesCount(sourceExplore.size()); //Nous mettons à jour le JLabel contenant le compteur de sources attribuée aux éclaireuses, qui est incrémenté à chaque passage
            //Si il y a moins de 20 sources de nourriture, le compteur s'arrêtera au nombre de sources disponibles, sinon, il ira jusqu'à 20
        }
            
        int taille = sourceExplore.size(); //Nous créons la variable taille, que nous allons utiliser uniquement dans cette méthode. Elle prends comme valeur la taille de la liste des sources explorés
        int nbemployee, condition; //Nous créons deux autres variables que nous allons également utiliser uniquement dans cette méthode
            
        System.out.println("Les employées interviennent"); //Nous informons l'utilisateur des abeilles qui vont intervenir

        for (int z = 0 ; z < taille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les employées, en utilisant la variable taille comme maximum
            assignationSourceEmployee(z); //Nous allons appeler la méthode assignationSourceEmployee, qui permet d'assigner une source trouvée par les éclaireuses à chaque employée
        }
            
        for (int z = 0 ; z < taille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les employées, en utilisant la variable taille comme maximum
            exploration(z); //Nous allons appeler la méthode exploration, qui permet aux employée d'atteindre la source qui leur est assignée
        }
            
        for (int z = 0 ; z < taille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les employées, en utilisant la variable taille comme maximum
            voisinage(z); //Nous allons appeler la méthode voisinage, qui permet aux employée de regarder autour de leur source s'il n'y a pas de sources de meilleure qualité
        }
            
        for (int z = 0 ; z < taille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les employées, en utilisant la variable taille comme maximum
            retour(z); //Nous allons appeler la méthode retour, qui permet aux employée de revenir à la ruche
        }

        System.out.println("Les observatrices interviennent"); //Nous informons l'utilisateur des abeilles qui vont intervenir

		assignationSourceObservatrice(); //Nous appelons la méthode assignationSourceObservatrice qui va permettre d'assigner la ou les meilleures sources trouvées aux observatrices

        for (int z = valeur + nbEclaireuses ; z < nbAbeille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
            exploration(z); //Nous allons appeler la méthode exploration, qui permet aux observatrices d'atteindre la source qui leur est assignée
        }
            
        for (int z = valeur + nbEclaireuses ; z < nbAbeille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
		    voisinage(z);  //Nous allons appeler la méthode voisinage, qui permet aux observatrices de regarder autour de leur source s'il n'y a pas de sources de meilleure qualité
        }

        for (int z = valeur + nbEclaireuses ; z < nbAbeille; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
		    retour(z); //Nous allons appeler la méthode retour, qui permet aux observatrices de revenir à la ruche
        }

        //Pour regarder ce que fait la condition d'arrêt nourriture il faudrai enlever la condition d'arrêt sourceMaximale
        while ((!sourceMaximale()) && (!nourriture())){ //Nous avons ici deux conditions d'arrêt, une pour le taux de nourriture, et l'autre si l'on a trouvé la source maximale
            sourceSupprime.clear();  //Nous allons vider la liste sourceSupprime 
            taille = sourceExplore.size(); //la variable taille est mise à jour à chaque itération avec la nouvelle taille de la liste sourceExplore
            condition = 0; //la variable condition prend la valeur 0
            nbemployee = 0; //la variable nbemployee prend la valeur 0
            for (int z = 0 ; z < taille ; z++){ //Nous créons une boucle pour compter combien d'employées ont une source attribuée
                if(((Employees) this.ab[z]).sourceN != -1){ //Nous regardons donc quand la source ne vaut pas -1 (condition qui existe dans le constructeur de cette classe qui le met à -1, et change de valeur uniquement lorsqu'on attribue une vraie source)
                    nbemployee += 1; //Si c'est le cas, nous incrémentons le nombre d'employées
                }
            }
            for (int num : sourceExplore) { //Nous allons maintenant parcourir la liste sourceExplore
                if(sc[num].detruite()){ //Et on vérifie si une source a été suffisamment exploré ou non
                    sc[num].move(0 , 0 ); //Si c'est le cas, on change les coordonnées en mettant celles de la ruche
                    sc[num].qualiteDetruite(0); //Et nous mettons la qualité à 0, afin qu'elle ne soit plus prise en compte par les observatrices, dans le cas où c'était la meilleure source de la liste
                    sourceSupprime.add(num); //Nous ajoutons alors dans la liste sourceSupprime le numéro de cette source
                }
            }
            for (int num : sourceSupprime) { //Nous allons maintenant parcourir la liste sourceSupprime
                abeille = -1; //Nous mettons la variable abeille à -1
                for (int z = valeur ; z < valeur + nbEclaireuses; z++ ){ //Nous créons une boucle pour voir si une des sources qu'une abeilel éclaireuse avait est supprimée
                    if (this.ab[z] instanceof Eclaireuses){ //Nous regardons si c'est bien une abeille éclaireuse
                        if(((Eclaireuses) this.ab[z]).sourceN == num){ //Si l'indice de la source attribuée à l'abeille correspond à l'indice de la source supprimée
                            abeille = z; //Nous stockons dans la variable abeille, l'indice de l'abeille éclaireuse
                        }
                    }
                }
                if((abeille != -1) && (nbemployee < valeur)){ //Nous vérifions que la variable abeille a bien l'indice d'une abeille éclaireuse et que le nombre d'employée qui ont une source est plus petit que le nombre de sources en tout (puisque nus avons autant d'employées que de sources et que si il y a 20 sources ou moins, la boucle s'arrête immédiatement)
                    System.out.println("Une source a été suffisamment visitée"); //Nous signalons à l'utilisateur ce qu'il va se passer, la source va être supprimée
                    System.out.println("L'éclaireuse qui avait cette source en cherche une autre"); //Une éclaireuse va refaire le tour de toutes les cases pour chercher une nouvelle source
                    roleEclaireuses(abeille); //Nous appelons la méthode roleEclaireuse, qui permet ainsi de faire le tour du plateau et selectionner une nouvelle source
                    System.out.println("Une nouvelle employée intervient"); //Ainsi une nouvelle employée va intervenir
                    assignationSourceEmployee(nbemployee); //Nous savons que le nombre d'employée correspond au dernier indice +1, ainsi nous pouvons garder la valeur que nous avons trouvé, et nous assignons cette nouvelle source à cette nouvelle abeille employée
                    condition += 1; //On incrémente la variable condition
                    nbemployee += 1; //on incrémente la variable employée
                }
                //Ces étapes vont se réaliser pour autant de sources supprimées qui étaient assignées à une abeille éclaireuse
            }

            System.out.println("Les employées interviennent"); //Nous informons l'utilisateur des abeilles qui vont intervenir
            
            for (int z = 0 ; z < nbemployee ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les employée ayant une source assignée
                exploration(z); //Nous allons appeler la méthode exploration, qui permet aux employées d'atteindre la source qui leur est assignée
            }
            
            if(condition != 0){ //Si condition est différent de 0, c'est qu'on a bien de nouvelles sources
                System.out.println("On fais le voisinage de notre nouvelle source"); //Nous signalons à l'utilisateru ce qu'il va se passer, il faut bien vérifier si il n'y a pas une meilleure source dans les parages
                for (int i = nbemployee - condition ; i < nbemployee; i++){ //Nous allons donc lancer la méthode qui nous permet de le faire, uniquement pour les nouvelles abeilles employées qui viennent d'avoir une nouvelle source
                    voisinage(i); //Nous appelons la méthode voisinage
                }
            }
            
            for (int z = 0 ; z < nbemployee ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les employées ayant une source assignée
                retour(z); //Nous allons appeler la méthode retour, qui permet aux employées de revenir à la ruche
            }

            System.out.println("Les observatrices interviennent"); //Nous informons l'utilisateur des abeilles qui vont intervenir

		    assignationSourceObservatrice(); //Nous allons appeler la méthode qui permet aux observatrices de se voir assigner une source (la meilleure)

            for (int z = valeur + nbEclaireuses ; z < nbAbeille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
                exploration(z); //Nous allons appeler la méthode exploration, qui permet aux observatrices d'atteindre la source qui leur est assignée
            }
            
            for (int z = valeur + nbEclaireuses ; z < nbAbeille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
	            voisinage(z); //Nous allons appeler la méthode voisinage, qui permet aux observatrices de regarder autour de leur source s'il n'y a pas de sources de meilleure qualité
            }

            for (int z = valeur + nbEclaireuses ; z < nbAbeille; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
		        retour(z); //Nous allons appeler la méthode retour, qui permet aux observatrices de revenir à la ruche
            }

        }
        colonieFrame.dispose(); //Permet de fermer la fenêtre quand le programme est terminé (qu'une condition d'arrêt ai marché)
	}

    public void roleEclaireuses(int z){ //Cette méthode nous permet d'effectuer le rôle des éclaireuses, elle prend en paramètre l'indice d'une abeille
	    if (this.ab[z] instanceof Eclaireuses){ //Nous vérifions que l'abeille soit bien une éclaireuse
            for (int i = this.tailleCase/2 ; i < this.width ; i += this.tailleCase ){  //Nous allons partir de la ruche jusqu'à atteindre la taille en horizontale du plateau
                for (int j = this.tailleCase/2; j < this.height ; j += this.tailleCase ){ //Nous allons partir de la ruche jusqu'à atteindre la taille en verticale du plateau
                    ((Eclaireuses) this.ab[z]).move(i, j); //Nous déplaçons l'abeille
                    coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                   try {
                        Thread.sleep(5); //Afin de visualiser le déplacement
                    } catch (InterruptedException e) {
                        e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
                    }
                }
            }
            int x = this.ab[z].getX(); //Nous créons et initialisons la variable x avec le x de l'abeille, elle ne sera utilisée que dans cette méthode
            int y = this.ab[z].getY(); //Nous créons et initialisons la variable y avec le y de l'abeille, elle ne sera utilisée que dans cette méthode
            for(int i = x ; i >= 0; i -= this.tailleCase ){ //Nous allons retourner à la ruche en partant du x où se trouvais l'abeille
                for (int j = y ; j >= 0 ; j -= this.tailleCase ){ //Nous allons retourner à la ruche en partant du y où se trouvais l'abeille
                    ((Eclaireuses) this.ab[z]).move(i, j); //Nous déplaçons l'abeilles
                    coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                   try {
                        Thread.sleep(5); //Afin de visualiser le déplacement
                    } catch (InterruptedException e) {
                        e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
                    }
                }
            }
            this.nb = this.numeroN; //La variable nb récupère la valeur de la variable numeroN
            if (z == this.valeur){ //Nous vérifions si l'indice de l'abeille correspond à la première abeille, si c'est le cas, la variable numeroN, n'a pas encore été initialisée, il nous faut donc donner une valeur à la variable nb
                nb = -1; //Nous lui donnons la valeur -1, pisque nous savons qu'aucune source a cette valeur en indice
            }
            while ((!assignationSourceEclaireuse(this.numeroN)) && (this.valeur != sourceExplore.size())){ //Nous appelons la méthode assignationSourceEclaireuse qui permet de savoir si l'indice à déjà été attribué à une abeille éclaireuse
                //Nous vérifions également que la liste des source explorée ne correspond pas ua nombre de sources que l'on a, puisque dans source explorée nous mettons les sources données aux éclaireuses
                //Si nous avons atteint le nombre de sources existant avant d'avoir attribuée une source à toutes les éclaireuses, il faut qu'on s'arrête, puisque tout possible indice a déjà été assigné. 
                this.numeroN = (int) (Math.random() * this.valeur); //Nous générons aléatoirement l'indice d'une des sources que l'on va donner à l'éclaireuse
            }
            if(this.nb != this.numeroN){ //Cette condition va être utile dans le cas où nous avons moins de sources que d'abeilles éclaireuses, en effet, grâce à nos conditions, nous entrerons plus dans le while précédent
                //Mais la variable numeroN reste avec une valeur assignée, ainsi, grâce à nb, nous vérifions quand, en deux tour de suite, nous avons le même indice, ce qui signifie que nous n'avons plus de sources
                //Cette condition permet d'éviter d'assigner aux éclaireuses qui restent la même source
                ((Eclaireuses) this.ab[z]).assignerSource(this.numeroN); //Nous assignons ici l'indice de la source à l'abeille
            }
	    }
    }

    public void assignationSourceEmployee(int z){ //Cette méthode nous permet d'assigner une source à chaque employée, en prenant en indice l'entier qui correspond à une abeille
	    if (this.ab[z] instanceof Employees){ //Nous véridions que c'est bien une abeille employée
            if(sourceExplore.size() <= nbEclaireuses){ //Si le nombre de sources est inférieur au nombre d'éclaireuses (soit 20), nous pouvons assigner chaque source sans nous inquiéter qu'il puisse y avoir des sources choisies deux fois
                ((Employees) this.ab[z]).assignerSource(sourceExplore.get(z)); //Nous assignons donc à chaue abeille employée une source (son indice)
                sc[sourceExplore.get(z)].abeilleAssignee(z); //Nous assignons à la source son abeille employée (son indice)
            }
            else {
                for (int num : sourceExplore) { //Nous allons si le nombre est supérieur parcourir la liste des sources explorées
                    if (abeille != -1) { //si abeille ne vaut pas -1 (condition que l'on fait dans le run ligne 143 - 147) ça veut dire qu'une éclaireuse a choisi une autre source non explorée
                        ((Employees) this.ab[z]).assignerSource(((Eclaireuses) this.ab[abeille]).sourceN); //Nous assignons donc à une nouvelle abeille employée la nouvelle source à explorer (son indice)
                        sc[((Eclaireuses) this.ab[abeille]).sourceN].abeilleAssignee(z); //Nous assignons à cette source son abeille employée (son indice)
                    }
                }
            }
        }
    }

    public void exploration(int z){ //Cette méthode nous permet de faire arriver nos abeilles à leurs sources respectives, en prenant en indice l'entier qui correspond à une abeille
	    if (this.ab[z] instanceof Employees){ //Nous regardons si l'abeille est une employée
            if((sc[((Employees) this.ab[z]).sourceN].getY() != 0) && (sc[((Employees) this.ab[z]).sourceN].getX() != 0)){ //Nous vérifions que la source ne soit pas aux coordonnées (0,0) puisque ça veut dire qu'elle a été détruite
                for (int j = this.tailleCase/2; j < (sc[((Employees) this.ab[z]).sourceN].getY() + this.tailleCase/2 +1) ; j += this.tailleCase ){ //Nous allons nous déplacer case par case jusqu'à atteindre le y de la source
                    ((Employees) this.ab[z]).move(this.ab[z].getX(), j); //Nous allons donc bouger notre abeille uniquement en fonction des y, en reprenant sa valeur de x
                    coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                    try {
                        Thread.sleep(5); //Afin de visualiser le déplacement
                    } catch (InterruptedException e) {
                        e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
                    }
                }
                for(int i = this.tailleCase/2 ; i < (sc[((Employees) this.ab[z]).sourceN].getX() + this.tailleCase/2 +1) ; i += this.tailleCase  ){ //Nous allons nous déplacer case par case jusqu'à atteindre le x de la source
                    ((Employees) this.ab[z]).move(i, this.ab[z].getY()); //Nous allons maintenant bouger notre abeille uniquement en fonction des x, en prenant sa nouvelle valeur y
                    coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                    try {
                        Thread.sleep(5); //Afin de visualiser le déplacement
                    } catch (InterruptedException e) {
                        e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
                    }
                }
                //Nous nous trouvons maintenant sur la source assignée
                ((Employees) this.ab[z]).recupereQualite(sc[((Employees) this.ab[z]).sourceN].getSC() ); //Nous allons recupérer la qualitée de la source sur laquelle nous sommes arrivés
                sc[((Employees) this.ab[z]).sourceN].visiter(); //Nous allons incrémenter le nombre de visite de la source
            }
        }
	    if (this.ab[z] instanceof Observatrices){ //Nous regardons si l'abeille est une observatrice
            if((sc[((Observatrices) this.ab[z]).sourceN].getY() != 0 ) && (sc[((Observatrices) this.ab[z]).sourceN].getX() != 0 )){ //Nous vérifions que la source ne soit pas aux coordonnées (0,0) puisque ça veut dire qu'elle a été détruite
                for (int j = this.tailleCase/2; j < (sc[((Observatrices) this.ab[z]).sourceN].getY() + this.tailleCase) ; j += this.tailleCase ){ //Nous allons nous déplacer case par case jusqu'à atteindre le y de la source
                    ((Observatrices) this.ab[z]).move(this.ab[z].getX(), j); //Nous allons donc bouger notre abeille uniquement en fonction des y, en reprenant sa valeur de x
                    coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                    try {
                        Thread.sleep(5); //Afin de visualiser le déplacement
                    } catch (InterruptedException e) {
                        e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
                    }
                }

                for(int i = this.tailleCase/2 ; i < (sc[((Observatrices) this.ab[z]).sourceN].getX() + this.tailleCase) ; i += this.tailleCase  ){ //Nous allons nous déplacer case par case jusqu'à atteindre le x de la source
                    ((Observatrices) this.ab[z]).move(i, this.ab[z].getY()); //Nous allons maintenant bouger notre abeille uniquement en fonction des x, en prenant sa nouvelle valeur y
                    coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                    try {
                        Thread.sleep(5); //Afin de visualiser le déplacement
                    } catch (InterruptedException e) {
                        e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
                    }
                }
                //Nous nous trouvons maintenant sur la source assignée
                ((Observatrices) this.ab[z]).recupereQualite(sc[((Observatrices) this.ab[z]).sourceN].getSC() ); //Nous allons recupérer la qualitée de la source sur laquelle nous sommes arrivés
                sc[((Observatrices) this.ab[z]).sourceN].visiter(); //Nous allons incrémenter le nombre de visite de la source
            }
        }
    }

    public void voisinage(int z){ //Cette méthode va nous permettre d'explorer le voisinage de la source d'une abeille, elle prend en paramètre l'indice de l'abeille
        int xSource , ySource, xAbeille, yAbeille; //Nous créons ces variables, que nous utiliseront uniquement dans cette méthode
        xSource = this.ab[z].getX() - this.tailleCase/2; //Nous stockons le x de la source où se trouve l'abeille
        ySource = this.ab[z].getY() - this.tailleCase/2; //Nous stockons le y de la source où se trouve l'abeille
        xAbeille = this.ab[z].getX(); //Nous stockons le x de l'abeille
        yAbeille = this.ab[z].getY(); //Nous stockons le y de l'abeille

	    if (this.ab[z] instanceof Employees){ //Nous regardons si l'abeille est une employée
            //Nous allons maintenant effectuer chaque déplacement autour de la source
            //On commence par le déplacement à droite (x + taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase, ySource); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées
            
            //Déplacement en bas à droite (x + taille d'une case et y + taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase, ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en bas (y + taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille  , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource , ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en bas à gauche (x - taille d'une case et y + taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement à gauche (x - taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en haut à gauche (x - taille d'une case et y - taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource - this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en haut (y - taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource , ySource - this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en haut à droite (x + taille d'une case et y - taille d'une case)
            ((Employees) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase, ySource - this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Nous déplaçons l'abeille au niveau de la source qui lui est assignée
            ((Employees) this.ab[z]).move(sc[((Employees) this.ab[z]).sourceN].getX() + this.tailleCase/2 , sc[((Employees) this.ab[z]).sourceN].getY() + this.tailleCase/2); 
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(150); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            
        }
	    if (this.ab[z] instanceof Observatrices){ //Nous regardons si l'abeille est une observatrice
            //Nous allons maintenant effectuer chaque déplacement autour de la source
            //On commence par le déplacement à droite (x + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase, ySource); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en bas à droite (x + taille d'une case et y + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase, ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en bas (y + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille  , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource , ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en bas à gauche (x - taille d'une case et y + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement à gauche (x - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en haut à gauche (x - taille d'une case et y - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource - this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en haut (y - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource , ySource - this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement en haut à droite (x + taille d'une case et y - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase , ySource - this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à droite (x + taille d'une case + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + (this.tailleCase * 2) , yAbeille); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + (this.tailleCase * 2), ySource); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à droite et en bas de 1 (x + taille d'une case + taille d'une case et y + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + (this.tailleCase * 2) , yAbeille + this.tailleCase ); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + (this.tailleCase * 2), ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à droite et en bas de 2 (x + taille d'une case + taille d'une case et y + taille d'une case + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + (this.tailleCase * 2) , yAbeille + (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + (this.tailleCase * 2), ySource + (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement à droite de 1 et en bas de 2 (x + taille d'une case et y + taille d'une case + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + this.tailleCase , yAbeille + (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase, ySource + (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement en bas (y + taille d'une case + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille  , yAbeille + (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource , ySource + (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement à gauche et en bas de 2 (x - taille d'une case et y + taille d'une case + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille + (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource + (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à gauche et en bas de 2 (x - taille d'une case - taille d'une case et y + taille d'une case + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - (this.tailleCase * 2) , yAbeille + (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - (this.tailleCase * 2) , ySource + (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à gauche et en bas de 1 (x - taille d'une case - taille d'une case et y + taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - (this.tailleCase * 2) , yAbeille + this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - (this.tailleCase *2), ySource + this.tailleCase); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à gauche (x - taille d'une case - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - (this.tailleCase * 2) , yAbeille); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - (this.tailleCase *2), ySource); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à gauche et en haut de 1 (x - taille d'une case - taille d'une case et y - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - (this.tailleCase *2) , yAbeille - this.tailleCase); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - (this.tailleCase *2) , ySource - this.tailleCase ); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à gauche et en haut de 2 (x - taille d'une case - taille d'une case et y - taille d'une case - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - (this.tailleCase * 2) , yAbeille - (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - (this.tailleCase *2) , ySource - (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement à gauche et en haut de 2 (x - taille d'une case et y - taille d'une case - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille - this.tailleCase , yAbeille - (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource - this.tailleCase , ySource - (this.tailleCase *2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement en haut (y - taille d'une case - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille , yAbeille - (this.tailleCase * 2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource , ySource - (this.tailleCase *2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Déplacement à droite et en haut de 2 (x + taille d'une case et y - taille d'une case - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + this.tailleCase, yAbeille - (this.tailleCase*2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + this.tailleCase , ySource - (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Double déplacement à droite et en haut de 2 (x + taille d'une case + taille d'une case et y - taille d'une case - taille d'une case)
            ((Observatrices) this.ab[z]).move(xAbeille + (this.tailleCase *2) , yAbeille - (this.tailleCase*2)); //Nous déplaçons l'abeille
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }
            meilleureSource(z, xSource + (this.tailleCase *2) , ySource - (this.tailleCase * 2)); //Nous appelons la méthode meilleure source pour regarder si une source existe à ces nouvelles coordonnées

            //Nous déplaçons l'abeille au niveau de la source qui lui est assignée
            ((Observatrices) this.ab[z]).move(sc[((Observatrices) this.ab[z]).sourceN].getX() + this.tailleCase/2 , sc[((Observatrices) this.ab[z]).sourceN].getY() + this.tailleCase/2); 
            coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
            try {
                Thread.sleep(15); //Afin de visualiser le déplacement
            } catch (InterruptedException e) {
                e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption
            }

        }
    }

    public void meilleureSource(int z, int xSource, int ySource){ //Cette méthode va nous servir pour savoir si dans le voisinage de la source nous avons une autre source avec une meilleure qualitée
        int val; //Nous créons la variable val, que nous utiliserons uniquement dans cette méthode
        for (int i = 0; i < sc.length; i++) { //Nous parcourons notre tableau de sources 
            val = 0;  //Nous initialisons la variable à 0 à chaque boucle
            for (int num : sourceExplore) { //Nous parcourons la liste sourceExplore 
                if (num == i) { //Nous regardons si la source à déjà été éxplorée (et donc se trouve dans la liste)
                    val = 1; //Si c'est le cas, nous mettons la variable val à 1
                }
            }
            if((sc[i].getX() == (xSource)) && (sc[i].getY() == ySource)){ //Nous regardons maintenant si il existe une source à la position que nous voulons tester
                if (this.ab[z] instanceof Employees){ //Nous regardons si l'abeilel est une employée
                    sc[((Employees) this.ab[z]).sourceN].visiter(); //Nous allons incrementer le nombre de visite de la source
                    if(sc[((Employees) this.ab[z]).sourceN].getSC() < sc[i].getSC()){ //Nous regardons si la qualité de la source trouvée est meilleure de la qualité que nous avons
                        ((Employees) this.ab[z]).assignerSource(i); //Si c'est le cas, on remplace l'indice de la source par la nouvelle source meilleure
                        sc[i].abeilleAssignee(z); //On dit à la source qu'elle a une certaine abeille employée assignée, en lui donnant son indice
                    }
                }
                if (this.ab[z] instanceof Observatrices){ //Nous regardons si l'abeilel est une observatrice
                    sc[((Observatrices) this.ab[z]).sourceN].visiter(); //Nous allons incrementer le nombre de visite de la source
                    if(sc[((Observatrices) this.ab[z]).sourceN].getSC() < sc[i].getSC()){ //Nous regardons si la qualité de la source trouvée est meilleure de la qualité que nous avons
                        ((Observatrices) this.ab[z]).assignerSource(i); //Si c'est le cas, on remplace l'indice de la source par la nouvelle source meilleure
                    }
                }
            }
            if (val == 0){ //Si val est à 0, ça veut dire que la source n'avais jamais été explorée
                sourceExplore.add(i); //Nous allons donc ajouter cette nouvelle source explorée à notre liste sourceExplore, puisque quand nous faisons le voisinage, les sources autour auront été visitée au moins une fois, nous explorons donc les sources
            }
        }
    }

    public void retour(int z){ //Cette méthode correspond au retour à la ruche, elle prend en paramètre un entier, qui correspond au numéro de l'abeille
        if (this.ab[z] instanceof Employees){ //Nous regardons si l'abeilel est une employée
            for (int j = (sc[((Employees) this.ab[z]).sourceN].getY() + this.tailleCase/2) ; j >= 0 ; j -= this.tailleCase ){ //Nous allons faire faire le parcours inverse à l'employée, elle va d'abord remonter tous les y, en partant de la position de la source, où elle se trouve
                ((Employees) this.ab[z]).move(this.ab[z].getX(), j); //Nous allons donc bouger notre abeille uniquement en fonction des y, en reprenant sa valeur de x
                coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                try {
                    Thread.sleep(5); //Afin de visualiser le déplacement
                } catch (InterruptedException e) {
                    e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption                      
                }
            }
            for(int i = (sc[((Employees) this.ab[z]).sourceN].getX() + this.tailleCase/2) ; i >= 0  ; i -= this.tailleCase ){ //Nous allons faire faire le parcours inverse à l'employée, elle va ensuite remonter tous les x, en partant de la position de la source où elle se trouvais, puisque le nombre de cases qu'il faut parcourir reste le même
                ((Employees) this.ab[z]).move(i, this.ab[z].getY()); //Nous allons ensuite bouger notre abeille uniquement en fontion des x en prenant le nouveau y
                coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                try {
                    Thread.sleep(5); //Afin de visualiser le déplacement
                } catch (InterruptedException e) {
                    e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption                       
                }
            }
            if(sc[((Employees) this.ab[z]).sourceN].getSC() != 0 ){ //Nous vérifions que la valeur de la qualité de la source est différente de 0, si c'est bien le cas
                ((Employees) this.ab[z]).danse(this.tailleCase , coloniePanel); //Nous allons faire la danse dans notre fenêtre, afin de communiquer la qualité
            }
        }

        if (this.ab[z] instanceof Observatrices){ //Nous regardons si l'abeilel est une observatrices
            for (int j = (sc[((Observatrices) this.ab[z]).sourceN].getY() + this.tailleCase/2) ; j >= 0 ; j -= this.tailleCase ){ //Nous allons faire faire le parcours inverse à l'observatrices, elle va d'abord remonter tous les y, en partant de la position de la source, où elle se trouve
                ((Observatrices) this.ab[z]).move(this.ab[z].getX(), j); //Nous allons donc bouger notre abeille uniquement en fonction des y, en reprenant sa valeur de x
                coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                try {
                    Thread.sleep(5); //Afin de visualiser le déplacement
                } catch (InterruptedException e) {
                    e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption                        
                }
            }
            for(int i = (sc[((Observatrices) this.ab[z]).sourceN].getX() + this.tailleCase/2) ; i >= 0  ; i -= this.tailleCase ){ //Nous allons faire faire le parcours inverse à l'observatrices, elle va ensuite remonter tous les x, en partant de la position de la source, où elle se trouvais, puisque le nombre de cases qu'il faut parcourir reste le même
                ((Observatrices) this.ab[z]).move(i, this.ab[z].getY()); //Nous allons ensuite bouger notre abeille uniquement en fontion des x en prenant le nouveau y
                coloniePanel.repaint(); //et nous allons réafficher pour voir le résultat
                try {
                    Thread.sleep(5); //Afin de visualiser le déplacement
                } catch (InterruptedException e) { 
                    e.printStackTrace(); //Imprime un message d'erreur en cas d'interruption                       
                }
            }
        }
    }

    public void assignationSourceObservatrice(){ //Cette méthode permet d'assigner une source aux observatrices
        maximum(); //Nous appelons la méthode maximum
        double degreErreur = 0.10; //Nous créons la variable degreErreur, que nous utiliserons uniquement dans cette méthode, elle correspond à une erreur de 10 %
        int erreur = (int) (50 * degreErreur); //Nous créons la variable erreur que nous utiliserons uniquement dans cette méthode, elle correpond au + ou _ possible par rapport aux valeurs de qualité des sources (des multiples de 50)
        int nouvelleQualite; //Nous créons la variable nouvelleQualite que nous utiliserons uniquement dans cette méthode
        if(nbSourceMax == 1) { //Nous regardons si la variable nbSourceMax est égale à 1, si c'est le cas, cela signifie que nous avons trouvé uniquement une seule source ayant la qualité maximale
            for (int z = valeur + nbEclaireuses ; z < nbAbeille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
                nouvelleQualite = max + (int) (Math.random() * (2 * erreur + 1)) - erreur;  //Nous donnons à la variable nouvelleQualite, la nouvelle valeur avec degré d'erreur aléatoire de la qualité
	            if (this.ab[z] instanceof Observatrices){ //Nous verifions bien que l'abeille est une observatrices
                    ((Observatrices) this.ab[z]).assignerSource(indiceSourceObservatrices.get(0)); //Nous assignons à l'abeille l'indice de la source qui lui est attribuée
                    ((Observatrices) this.ab[z]).recupereQualite(nouvelleQualite); //Nous assignons à l'abeille la valeur de la qualité avec le degré d'erreur
                }
            }
        }
        if (nbSourceMax > 1){ //Nous regardons si la variable nbSourceMax est supérieur à 1, si c'est le cas, cela signifie que nous avons trouvé plusieuts sources ayant la qualité maximale
            int div = nbObservatrices / nbSourceMax; //Nous créons et initialisons la variable div, qui ne sera présente que dans cette méthode, elle nous permet de savoir combien d'abeilles vont dans les sources trouvées
            int c; //Nous créons la variable c qui ne sera utilisée que dans cette méthode
            c = 0; //Nous donnons à la variable c la valeur de 0
            for (int z = valeur + nbEclaireuses ; z < nbAbeille ; z++){ //Nous créons une boucle pour faire faire certaines actions à toutes les observatrices
                nouvelleQualite = max + (int) (Math.random() * (2 * erreur + 1)) - erreur; //Nous donnons à la variable nouvelleQualite, la nouvelle valeur avec degré d'erreur aléatoire de la qualité
                if (c == nbSourceMax) { //Lorsque nous avons atteint le nombre de source maximale trouvée
                    c = 0; //Nous remettons la variable c à 0
                }
                ((Observatrices) this.ab[z]).assignerSource(indiceSourceObservatrices.get(c)); //Nous assignons à l'abeille l'indice de la source qui lui est attribuée
                ((Observatrices) this.ab[z]).recupereQualite(nouvelleQualite); //Nous assignons à l'abeille la valeur de la qualité avec le degré d'erreur
                c ++; //On incrémente la variable c
                //Donc à chaque fois, à chaque nouvelle abeille nous assignons une nouvelle source trouvée, jusqu'à les avoir toutes assignée une fois et on recommence
            }
            if((div * nbSourceMax) != nbObservatrices){ //Nous regardons si nous avons bien assigné uen source à toutes les observatrices, puisque dans le cas où notre nombre de source trouvé n'est pas un diviseur du nombre des observatrices, il va arrondir la valeur et on aura une perte d'information
                int diff = nbObservatrices - (div * nbSourceMax); //Nous créons et initialisons la variable diff, qui va donc contenir le nombre d'observatrices pour lesquelles nous n'avons pas de source attribuée (nous faisons la différence entre le nombre d'observatrices et le nombre d'abeilles que l'on a mis par source)
                for (int i = nbAbeille - diff - 1; i < nbAbeille; i++){ //Nous créons une boucle pour faire faire certaines actions aux observatrices qui n'on pas de source
                    nouvelleQualite = max + (int) (Math.random() * (2 * erreur + 1)) - erreur; //Nous donnons à la variable nouvelleQualite, la nouvelle valeur avec degré d'erreur aléatoire de la qualité
                    ((Observatrices) this.ab[i]).assignerSource(indiceSourceObservatrices.get(nbSourceMax-1)); //Nous assignons à l'abeille l'indice de la source qui lui est attribuée
                    ((Observatrices) this.ab[i]).recupereQualite(nouvelleQualite); //Nous assignons à l'abeille la valeur de la qualité avec le degré d'erreur
                }
            }
        }
    }

    void maximum(){ //Cette methode va servir pour déterminer la qualité maximale que nous avons parmi les sources explorés, puisque la meilleure qualité en absolue pourrai ne pas avoir été trouvée
        max = 0; //Nous initialisons la variable max à 0
        indiceSourceObservatrices.clear(); //Nous vidons la liste indiceSourceObservatrices
        for (int num : sourceExplore) { //Nous allons parcourir la liste sourceExplore
            if (max < sc[num].getSC()) { //Si notre maximum est inférieur à la qualité de la source
                max = sc[num].getSC(); //On remplace notre valeur par la nouvelle qui est plus importante
            }
        }
        nbSourceMax = 0 ; //Nous initialisons la variable nbSourceMax à 0
        for (int num : sourceExplore) { //Nous allons parcourir la liste sourceExplore
            if (max == sc[num].getSC()) { //Nous allons regarder quand est-ce que la qualité de la source équivaut à la meilleure qualité trouvée dans la liste
                nbSourceMax += 1; //Si c'est le cas nous incrémentons la variable nbSourceMax
                indiceSourceObservatrices.add(num); //Et nous ajoutons l'indice de la source à notre liste indiceSourceObservatrices
            }
        }
        //La deuxième étape est importante, puisque nous pouvons avoir une seule source avec qualité maximale exploré, comme nous pouvons en avoir plusieurs
        colonieFrame.updateEmployeeSource(max); //Nous modifions la valeur du JLabel en affichant la meilleure source découverte lors de l'exploration
    }

    public boolean sourceMaximale(){ //Cette méthode correspond à une des conditions d'arrêt
        for (int num : sourceExplore) { //Nous allons parcourir la liste sourceExplore
            if (sourceMAX == sc[num].getSC()) { //Si la qualité d'une des sources déjà exploré correspond à la qualité de la meilleure source
                System.out.println("Nous avons trouvé la source de nourriture ayant la quantité maximale : " + sourceMAX + "!"); //Nous signalons à l'utilisateur que nous avons trouvé la meilleure qualité et sa valeur
                return true; //Nous retournons vrai pour arrêter la boucle
            }
        }
        return false; //Sinon on met faux d'office pour continuer la boucle
    }

    public boolean nourriture(){ //Cette méthode correspond à une des conditions d'arrêt
        int nombre; //Nous créons cet entier que nous utiliserons uniquement dans cette méthode
        nombre = 0; //Nous l'initialisons à 0
        for (int num : sourceExplore) { //Nous allons parcourir notre liste sourceExplore
            if(sc[num].abeille != -1 ){ //Nous vérifions si la source a bien une abeille d'assignée
                nombre += sc[num].qualite; //Nous allons faire la somme de toutes les qualités
            }
        }
        //Nous obtenons donc le nombre de nourriture que nous avons a disposition grâce aux abeilles
        colonieFrame.updateNourritureObtenue(nombre); //on met à jour dans l'affichage des JLabel dans ColonieFrame le numéro de nourriture obtenue
        if((nbAbeille * 150) <= nombre){ //Nous mettons comme base que chaque abeille a besoin de 150 de nourriture, ainsi pour savoir combien de nourriture il nous faut pour nourrire toutes les abeilles, on multiplie le nombre d'abeilles par 150
            //Nous regardons ensuite si cette valeur est plus petite ou égale au nombre de nourriture que nous avons
            System.out.println("Nous avons trouvé suffisamment de nourriture ! "); //Si c'est le cas c'est que nous avons trouvé suffisamment de nourriture, nous le signalons à l'utilisateur
            return true; //Nous retournons true afin d'arrêter la boucle
        }
        if((sourceExplore.size() == valeur) && (valeur > 20) ){ //En revanche, si on a parcouru/exploré toutes les sources et que le nombre de sources est supérieur à 20 (puisque inférieur à 20 c'est l'autre condition d'arrêt qui déclenchera l'arrêt du programme)
            System.out.println("Il n'y aura pas assez de nourriture "); //Cela signifie qu'il n'y aura pas assez de nourriture
            return true; //On retourne true pour arrêter la boucle, puisque un résultat devient impossible
        }
        return false; //sinon on retourne false
        //Il est plus intéressant de tester cette condition seule sans la condition meilleure source, puisque si on parcours toutes les sources, nous aurons obligatoirement trouvé la meilleure source
    }

    public boolean positionSource(int nb1, int nb2, int qualite){ //Méthode position source
        //Cette méthode nous permet de savoir si notre source a de bons paramètres qui respectent certaines positions
        for (int i = 0; i < sc.length; i++) { //Nous allons parcourir le tableau sc
            if((sc[i] != null) && (sc[i].getX() == nb1) && (sc[i].getY() == nb2)){ //Et ici nous regardons, si la case est remplie, et que le x et le y que nous essayons d'attribuer à cette nouvelle source sont déjà attribués à une autre source
                return false; //Nous mettons le résultat à faux pour en générer d'autres
            }
        }
        return (nb1 % this.tailleCase == 0) && (nb2 % this.tailleCase == 0) && (qualite % 50 == 0); //Nous retournons alors le x, le y et la qualité, et on regarde bien si c'est un multiple de la taille de nos cases ou 50 pour la qualité
        //Nous devons réaliser cette étape, puisque sinon, notre source pourrai s'afficher entre deux cases
        //Ainsi, si les valeurs sont des multiples, ça renverra vrai, sinon, si une seule ne correspond pas, ça répondra faux
	}    
    
    public boolean assignationSourceEclaireuse(int numero) { //Cette méthode nous permet d'assigner une source à une éclaireuse, en prenant en paramètre un entier
        for (int num : sourceExplore) { //Nous parcourons la liste sourceExplore
            if (num == numero) { //Si cette source est déjà dans la liste, ça signifie qu'elle a déjà été attribuée ou explorée
                return false;  //Nous devons donc trouver une autre source
            }
        }
        sourceExplore.add(numero); //Si c'est une nouvelle valeur, nous l'ajoutons à la liste
        return true; //Et nous retournons vrai pour avancer
    }
  

    public static void main(String[] args) { //Nous avons ici notre main, qui va nous permettre de lancer nos programmes
        Colonie c = new Colonie(700, 700, 50, 59); //Nous créons notre Colonie avec les paramètres d'initialisation
        c.run(); //Nous lanços la méthode run de notre Colonie
    }
    
}