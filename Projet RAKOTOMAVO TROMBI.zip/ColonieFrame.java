//Nous faisons les import nécessaire pour utiliser les différentes structures de java
import javax.swing.*;
import java.awt.*;

public class ColonieFrame extends JFrame { //la classe ColonieFrame hérite de JFrame
    //Création de variables
    ColoniePanel coloniePanel; //nous avons ici une variable de type ColoniePanel (qui correspond à l'affichage de nos composants et notre grille)
    JLabel nbSourcesJLabel, nbSourceMax, nbNourriture, nbNourritureObtenue; //Nous créons ici des champs texte que nous allons implémenter dans notre fenêtre


    public ColonieFrame(ColoniePanel coloniePanel) { //constructeur de cette classe, nous prenons comme paramètre à l'intérieur un objet ColoniePanel
        super("Colonie d'abeilles"); //Nous allons afficher comme titre de notre fenêtre, le titre de notre sujet
        this.coloniePanel = coloniePanel; // Nous allons stocker dans notre variable l'objet pris en paramètre
     
        nbSourcesJLabel = new JLabel("Nombre de sources détectées par les éclaireuses : 0"); //Nous créons ici le texte affiché
        nbSourceMax = new JLabel("Meilleure qualité de source sur la colonie : 0"); //Nous créons ici le texte affiché
        nbNourriture = new JLabel("Nourriture qu'il faut aux abeilles : 0"); //Nous créons ici le texte affiché
        nbNourritureObtenue = new JLabel("Nourriture que nous avons a disposition : 0"); //Nous créons ici le texte affiché

        JPanel infoPanel = new JPanel(new GridLayout(2, 3)); //Nous créons un JPanel afin de nous permettre l'affichage, nous sommes sur deux lignes et 3 colonnes
        infoPanel.add(nbSourcesJLabel); //nous ajoutons ici à ce nouveau JPanel nos JLabel, champs texte, qui seront affichés
        infoPanel.add(nbSourceMax); //nous ajoutons ici à ce nouveau JPanel nos JLabel, champs texte, qui seront affichés
        infoPanel.add(nbNourriture); //nous ajoutons ici à ce nouveau JPanel nos JLabel, champs texte, qui seront affichés
        infoPanel.add(nbNourritureObtenue); //nous ajoutons ici à ce nouveau JPanel nos JLabel, champs texte, qui seront affichés
       

        JPanel mPanel = new JPanel(); //Nous créons ici un autre JPanel, qui va nous permettre de tout mettre ensemble
        mPanel.setLayout(new BorderLayout()); //Nous allons ici crée un nouveau bord pour ce pannel
        mPanel.add(infoPanel, BorderLayout.NORTH); //Tout en haut, nous allons ajouter notre JPanel qui contient les champs texte
        mPanel.add(coloniePanel, BorderLayout.CENTER); //puis au centre juste en dessous, nous allons ajouter notre JPanel qui nous permet d'avoir les composants et la grille


        add(mPanel); //nous allons donc ajouter à l'affichage ce nouveau JPanel qui contient tous les éléments que nous voulons
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Nous décidons que le programme s'arrête dès que la fenêtre est fermée
        pack(); //nous le laissons prendre la taille nécessaire à l'affichage de notre fenêtre
        setLocation(100,25); //afin qu'elle soit plus centrale, nous affichons notre fenêtre détachée des bords de l'écran
        setResizable(false); //nous bloquons la possibilité de changer la taille de la fenêtre
        setVisible(true); //nous permettons l'affichage de notre fenêtre
    }

    //méthode qui nous permet de mettre à jour quand une éclaireuse a une source de nourriture associée, prend en paramètre le nombre de sources associés
    public void updateEclaireusesCount(int count) { 
        nbSourcesJLabel.setText("Nombre de sources détectées par les éclaireuses : " + count + " "); //nous modifions l'affichage afin d'avoir à la place du 0, la vrai valeur
    }

    //méthode qui nous permet de mettre à jour le nombre de sources associés à une éclaireuse par la meilleure source que nous avons selectionné
    public void updateEmployeeSource(int count) { //prend en paramètre la qualité de la meilleure source
        nbSourcesJLabel.setText("Meilleure qualité de source que nous avons : " + count + " "); //on l'affiche en modifiant l'affichage
    }

    //méthode qui nous permet de mettre à jour le taux de nourriture qu'il faut 
    public void updateNourriture(int count) { //prend en paramètre la valeur de nourriture qu'il faut pour nourrire toutes les abeilles de la ruche
        nbNourriture.setText("Nourriture qu'il faut aux abeilles : " + count + " "); //nous modifions l'affichage afin d'avoir à la place de 0, la vrai valeur
    }

    //méthode qui nous permet de mettre à jour le taux de nourriture que nous avons trouvé jusque là 
    public void updateNourritureObtenue(int count) { //prend en paramètre la valeur de nourriture que nous avons à disposition
        nbNourritureObtenue.setText("Nourriture que nous avons a disposition : " + count + " "); //nous modifions l'affichage afin d'avoir à la place de 0, la vrai valeur
    }

    //méthode qui nous permet de mettre à jour la meilleure qualité sur la fenêtre
    public void updateSourceMaxCount(int count) { //prend en paramètre la qualité maximale de source de nourriture qui est présente sur la fenêtre
        nbSourceMax.setText("Meilleure qualité de source sur la colonie : " + count + " "); //nous modifions l'affichage afin d'avoir à la place de 0, la vrai valeur
    }
}




