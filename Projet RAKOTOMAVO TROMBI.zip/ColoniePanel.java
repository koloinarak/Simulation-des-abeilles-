//Nous faisons les import nécessaire pour utiliser les différentes structures de java
import javax.swing.*;
import java.awt.*;
import java.util.*;

public class ColoniePanel extends JPanel { //la classe ColoniePanel hérite de JPanel
    //Création de variables
    Abeille[] ab;
    SC[] sc;
    int tailleCase ;

    public ColoniePanel(Abeille[] ab, SC[] sc, int cases) { //constructeur de ColoniePanel, qui nous permet d'initialiser certaines variables
        this.ab = ab; //nous replissons notre liste Abeille
        this.sc = sc; //nous remplissons notre liste source
        this.tailleCase = cases; //nous allons stocker la taille des cases choisi
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        dessinerBordure(g); //nous appelons d'abord la bordure
        dessinerRuche(g); //puis la ruche
        dessinerSource(g); //ensuite les sources
        dessinerAbeilles(g); // les abeilles
        dessinerColonie(g); //et pour finir la colonie (permet l'affichage de la grille)
        /* l'ordre est très important, puisque sinon, certains composants ne seront plus visible
        en effet si je met d'abord les abeilles et ensuite tout le reste, les abeilles ne seront 
        plus visibles sur les cases comme la ruche ou les sources, lorsqu'elle devra se déposer dessus.
        Pour bien voir la grille qui délimite, nous la mettons en dernière afin qu'elle soit au dessus de tous les composants*/
    }

    private void dessinerColonie(Graphics g) { //nous permet de dessiner notre colonie
        int largeur = getWidth() - 2; //ici nous prenons en compte la bordure
        int hauteur = getHeight() - 2; //ici nous prenons en compte la bordure
        
        g.setColor(Color.BLACK); //la couleur de nos lignes
        
        //nous allons mainteannt créer le cadrillage
        for (int y = 0; y <= hauteur; y += this.tailleCase) { //nous traçons des lignes verticales
            g.drawLine(1, y + 1, largeur + 1, y + 1); //traçage des lignes
        }
        
        for (int x = 0; x <= largeur; x += this.tailleCase) { //nous traçons des lignes horizontales
            g.drawLine(x + 1, 1, x + 1, hauteur + 1);//traçage des lignes
        }
    }

    private void dessinerBordure(Graphics g) { //nous permet de tracer la bordure
        g.setColor(Color.BLACK); //la couleur est noire
        g.drawRect(0, 0, getWidth() - 1, getHeight() - 1); //nous dessinons un grand rectangle
    }    

    private void dessinerAbeilles(Graphics g) { //nous permet de dessiner les abeilles
        for (Abeille a : ab) { //nous parcourons notre liste d'abeilles
            a.paint(g); //nous appelons la méthode paint de notre classe abeille
        }
    }

    private void dessinerSource(Graphics g) { //nous permet de dessiner les sources de nourritures
        for (SC sc1 : sc) { //nous parcourons la liste de sources de nourritures
            if((sc1.getX() != 0) && (sc1.getY() != 0) ){ //nous vérifions bien que la source ne se trouve pas au même endroit que notre ruche
                if(sc1.qualite > 900){ //en fontion de la qualité, nous aurons une couleur respective
                    g.setColor(new Color(255, 255,0)); //nous partons du jaune
                }
                else if(sc1.qualite > 800){
                    g.setColor(new Color(255, 235,0)); 
                }
                else if(sc1.qualite > 700){
                    g.setColor(new Color(255, 215,0)); 
                }
                else if(sc1.qualite > 600){
                    g.setColor(new Color(255, 195,0)); 
                }
                else if(sc1.qualite > 500){
                    g.setColor(new Color(255, 175,0)); 
                }
                else if(sc1.qualite > 400){
                    g.setColor(new Color(255, 155,0)); 
                }                
                else if(sc1.qualite > 300){
                    g.setColor(new Color(255, 135,0)); 
                }
                else if(sc1.qualite > 200){
                    g.setColor(new Color(255, 115,0)); 
                }
                else if(sc1.qualite > 100){
                    g.setColor(new Color(255, 95,0)); 
                }
                else if(sc1.qualite > 0){
                    g.setColor(new Color(255, 75,0)); //la couleur devient de plus en plus foncée jusqu'à arriver dans les rouges
                }
                g.fillRect(sc1.getX() + 1 , sc1.getY() + 1 , this.tailleCase + 1, this.tailleCase + 1); //les sources prennent une forme de rectangle, occupant toute une case
            }
        }
    }

    private void dessinerRuche(Graphics g) {// permet de dessiner la ruche où toutes les abeilles se trouvent
        g.setColor(new Color(139, 69, 19));  //la ruche sera de couleur marron
        g.fillRect(1 , 1 , this.tailleCase + 1, this.tailleCase + 1);  //sous la forme d'un rectangle qui se trouvera en première position tout en haut à gauche
    }

}
