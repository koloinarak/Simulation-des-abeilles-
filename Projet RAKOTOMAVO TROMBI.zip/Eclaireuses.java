//Nous faisons les import nécessaire pour utiliser les différentes structures de java
import java.awt.Color;

class Eclaireuses extends Abeille { //classe eclaireuses qui hérite de abeille
    //Création de variables
    int sourceN;

    Eclaireuses(int x, int y, Color c){// constructeur de la classe eclaireuses
        super(x, y, c); //grâce à l'héritage, nous récupérons les informations propres à toutes les abeilles
    }


    void move (int x, int y){ //permet à l'abeille de se déplacer 
		this.x = x;
		this.y = y;
	}

    void assignerSource(int sourceN){ //permet d'assigner le numéro d'une des sources de nourritures à l'abeille
        this.sourceN = sourceN;
    }

}

