//Nous faisons les import nécessaire pour utiliser les différentes structures de java
import java.awt.Color;

class Employees extends Abeille { //classe employees qui hérite de abeille
    //Création de variables
    int sourceN, qualite;

    Employees(int x, int y, Color c){ //constructeur de la classe employees
        super(x, y, c); //grâce à l'héritage, nous récupérons les informations propres à toutes les abeilles
		sourceN = -1; //nous initialisons les autres variables présentes
		qualite = -1;
    }

    void assignerSource(int sourceN){ //permet d'assigner le numéro d'une des sources de nourritures à l'abeille
        this.sourceN = sourceN;
    }

    void recupereQualite(int q){ //nous permet de recuperer la qualite d'une source
        this.qualite = q;
    }

    void move (int x, int y){//permet à l'abeille de se déplacer 
		this.x = x;
		this.y = y;
	}

    void danse (int cases, ColoniePanel coloniePanel){//permet à l'abeille d'effectuer la danse, lorsqu'elle a exploré une source de nourriture 
        for (int i = 0; i < cases; i+= (cases/5)){ //nous allons donc parcourir la ruche pour effectuer la danse
		    for (int j = 0; j < cases; j+= (cases/5)){
    		    move(i,j);
                coloniePanel.repaint(); //nous allons reafficher pour voir le déplacement
                try {
                    Thread.sleep(15); //afin d'observer le mouvement de l'abeille
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
	        }
        }

	    move(cases/2 , cases/2); //nous revenons au placement initial d'une abeille dans la ruche
        coloniePanel.repaint(); //nous allons reafficher afin d'observer le déplacement   
        try {
            Thread.sleep(5);  //afin d'observer le mouvement de l'abeille
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}

}
