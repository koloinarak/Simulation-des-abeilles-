
class SC { //Classe pour les sources de nourriture
    //Création de variables
    int x, y, visite, qualite, i, abeille;
    
    SC(int x, int y, int q, int v) { //Constructeur, permet d'initialiser les differentes variables
        this.x = x;
        this.y = y;
        this.qualite = q;
        this.visite = v;
        this.i = 0;
        this.abeille = -1;
    }

    int getX () { //methode qui permet de recuperer le x (abscisse de la source)
        return this.x;
    }

    int getY () { //methode qui permet de recuperer le y (l'ordonne de la source)
        return this.y;
    }

    int getSC () { //methode qui permet de recuperer la qualite de la source
        return this.qualite;
    }

    void move (int x, int y){//permet le déplacement de la source lorsqu'elle doit être détruite 
		this.x = x;
		this.y = y;
	}

    void qualiteDetruite (int q){//nous permet de changer la qualité de la source lorsqu'elle doit être détruite
		this.qualite = q;
	}

    void visiter(){ //methode qui permet d'incrementer le nombre de visite
        this.i = this.i + 1;
    }

    void abeilleAssignee(int a){ //methode qui permet de savoir si une abeille employee s'occupe déjà de cette source
        this.abeille = a;
    }

    boolean detruite(){ //methode qui permet de savoir si la source a été visitée suffisamment de fois
        if(i >= visite){ //si nous avons visité suffisamment ou plus de fois que prévu, nous allons détruire la source concernée
            return true;
        }
        else{
            return false;
        }
    }

}